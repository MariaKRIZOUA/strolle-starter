'use client'
import { useEffect,useState } from 'react'
import { supabase } from '@/src/lib/supabaseClient'
import { useRouter } from 'next/navigation'
export default function AuthGate({children}:{children:React.ReactNode}){
  const [loading,setLoading]=useState(true); const [session,setSession]=useState<any>(null); const router=useRouter()
  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>{setSession(data.session);setLoading(false)})
    const { data: sub } = supabase.auth.onAuthStateChange((_e,s)=>{setSession(s); if(!s) router.push('/(auth)/login')})
    return ()=>sub.subscription.unsubscribe()
  },[router])
  if(loading) return <p>Chargement…</p>
  if(!session) return null
  return <>{children}</>
}
