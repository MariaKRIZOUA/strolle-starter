'use client'
import { supabase } from '@/src/lib/supabaseClient'
import { useState } from 'react'
export default function LoginPage(){
  const [email,setEmail]=useState(''); const [sent,setSent]=useState(false); const [err,setErr]=useState<string|null>(null)
  const send=async()=>{ setErr(null)
    const { error } = await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: `${window.location.origin}/dashboard`} })
    if(error) setErr(error.message); else setSent(true)
  }
  return(<main style={{maxWidth:480,margin:'0 auto',padding:24}}><h2>Connexion / Préinscription</h2><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="votre@email" style={{width:'100%',padding:12,margin:'12px 0'}}/><button onClick={send} style={{padding:12}}>Recevoir le lien</button>{sent&&<p>Vérifiez votre boîte mail 💚</p>}{err&&<p style={{color:'crimson'}}>{err}</p>}</main>)}
