'use client'
import AuthGate from '@/src/components/AuthGate'
export default function Dashboard(){return(<AuthGate><main style={{maxWidth:900,margin:'0 auto',padding:24}}><h2>Bienvenue sur Strollé 💚</h2></main></AuthGate>)}
