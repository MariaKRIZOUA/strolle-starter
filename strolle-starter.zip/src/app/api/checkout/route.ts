import { NextResponse } from 'next/server'
import { stripe } from '@/src/lib/stripe'

export async function POST(req: Request) {
  try {
    const { priceId, email } = await req.json()
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer_email: email,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?ok=1`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/?cancel=1`
    })
    return NextResponse.json({ url: session.url })
  } catch (e:any) {
    return NextResponse.json({ error: e.message }, { status: 400 })
  }
}
